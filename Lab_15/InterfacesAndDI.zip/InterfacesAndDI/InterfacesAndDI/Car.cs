﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesAndDI
{
    public class Car
    {

        private readonly IEngine _engine;

        // Fields
        public string Model { get; private set; }
        public int Year { get; private set; }

        // Constructor
        public Car(string model, int year, IEngine engine)
        {
            Model = model;
            Year = year;
            _engine = engine;
        }

        // Methods
        public void Start()
        {
            Console.WriteLine($"{Year} {Model} is starting.");
            // Delegating the engine start to the injected engine
            _engine.Start();
        }

        public void Accelerate()
        {
            Console.WriteLine($"{Year} {Model} is accelerating.");
            // Delegating the engine accelerate to the injected engine
            _engine.Accelerate();
        }

        public void Stop()
        {
            Console.WriteLine($"{Year} {Model} is stopping.");
            // Delegating the engine stop to the injected engine
            _engine.Stop();
        }
    }
}
