﻿namespace InterfacesAndDI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Creating Car instances
            Car myCar = new Car("Ford Puma", 2022, new GasEngine());
            Car anotherCar = new Car("Honda Accord", 2021, new ElectricEngine());
            // Using Car methods
            myCar.Start();
            anotherCar.Start();

            myCar.Accelerate();
            anotherCar.Accelerate();

            myCar.Stop();
            anotherCar.Stop();
        }
    }
}