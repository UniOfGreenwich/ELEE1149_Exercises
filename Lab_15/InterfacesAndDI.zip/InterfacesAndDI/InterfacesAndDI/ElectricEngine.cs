﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesAndDI
{
    internal class ElectricEngine : IEngine
    {
        public void Accelerate()
        {
            Console.WriteLine("Electric engine accelerating.");
        }

        public void Start()
        {
            Console.WriteLine("Electric engine started.");
        }

        public void Stop()
        {
            Console.WriteLine("Electric engine stopped.");
        }

        public void Temperature()
        {
            //TODO
        }
    }
}
