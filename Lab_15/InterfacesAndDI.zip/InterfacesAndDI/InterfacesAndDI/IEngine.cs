﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesAndDI
{
    public interface IEngine
    {
        void Start();

        void Stop();

        void Accelerate();

        void Temperature();
    }
}
