﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesAndDI
{
    internal class GasEngine : IEngine
    {
        public void Accelerate()
        {
            Console.WriteLine("Gas engine accelerating.");
        }

        public void Start()
        {
            Console.WriteLine("Gas engine started.");
        }

        public void Stop()
        {
            Console.WriteLine("Gas engine stopped.");
        }

        public void Temperature()
        {
            //TODO
        }
    }
}
